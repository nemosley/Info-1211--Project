<?php
/**
 * Base view class providing header and footer methods.
 */

class View
{
    public function header($title = 'Final Project')
    {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title><?= htmlspecialchars($title) ?></title>
            <link rel="stylesheet" href="<?= BASE_URL ?>/public/css/style.css">
        </head>
        <body>
        <div class="container">
        <?php
    }

    public function footer()
    {
        ?>
        </div>
        </body>
        </html>
        <?php
    }
}
