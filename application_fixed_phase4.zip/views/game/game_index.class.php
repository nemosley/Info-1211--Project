<?php
/**
 * Author: Charley Corneil
 * File: game_index.class.php
 * Description: View to present all products (games inventory) as cards with bordered header and footer.
 */
class GameIndex extends View
{
    public function display($games)
    {
        $this->header("Games Inventory");
        ?>

        <!-- Header -->
        <div class="inventory-header">
            <div class="header-left">
                <h1>🎮 Game Inventory</h1>
                <p>Browse our collection of games across platforms and genres.</p>
            </div>
            <!-- ✅ Add New Game Button -->
            <div class="header-right">
                <a href="<?= BASE_URL ?>/index.php?url=game/create" class="add-btn">➕ Add New Game</a>
            </div>
        </div>

        <!-- ✅ SEARCH BAR UNDER HEADER -->
        <div class="search-bar">
            <label for="q" class="search-label">Search games by title (multi‑word OR)...</label>
            <div class="search-row">
                <input id="q" type="text" placeholder="Search games..." />
                <button id="search-btn">Search</button>
            </div>
        </div>

        <!-- AJAX Search Results -->
        <div id="results"></div>

        <!-- Game Cards -->
        <div class="middle-row" id="card-list">
            <?php if (empty($games)): ?>
                <p style="text-align:center;">No games found.</p>
            <?php else: ?>
                <div class="card-container">
                    <?php foreach ($games as $game):
                        $title    = htmlspecialchars($game['title'] ?? 'Untitled');
                        $platform = htmlspecialchars($game['platform'] ?? 'Unknown');
                        $category = htmlspecialchars($game['category'] ?? $this->inferGenre($game['title'] ?? ''));
                        $price    = isset($game['price']) ? number_format((float)$game['price'], 2) : '0.00';
                        $stock    = isset($game['stock']) ? (int)$game['stock'] : 0;
                        $gameId   = (int)($game['game_id'] ?? 0);
                        ?>
                        <div class="game-card">
                            <h3><?= $title ?></h3>
                            <p><strong>Platform:</strong> <?= $platform ?></p>
                            <p><strong>Category:</strong> <?= $category ?></p>
                            <p><strong>Price:</strong> $<?= $price ?></p>
                            <p><strong>Stock:</strong> <?= $stock ?> available</p>
                            <a href="<?= BASE_URL ?>/index.php?url=game/detail/<?= $gameId ?>" class="details-btn">
                                View Details
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="inventory-footer">
            <p>Group 5 | INFO-I 211 | Fall 2025</p>
        </div>

        <!-- ✅ AJAX Search Script -->
        <script>
            (function () {
                const baseUrl    = "<?= BASE_URL ?>";
                const input      = document.getElementById("q");
                const button     = document.getElementById("search-btn");
                const resultsDiv = document.getElementById("results");
                const cardList   = document.getElementById("card-list");

                function escapeHtml(str) {
                    if (!str) return "";
                    return str
                        .replace(/&/g, "&amp;")
                        .replace(/</g, "&lt;")
                        .replace(/>/g, "&gt;")
                        .replace(/"/g, "&quot;")
                        .replace(/'/g, "&#039;");
                }

                function clearResults() {
                    resultsDiv.innerHTML = "";
                    cardList.style.display = "block";
                }

                function renderCards(games) {
                    if (!Array.isArray(games) || games.length === 0) {
                        resultsDiv.innerHTML = "<p style=\"text-align:center;\">No games found.</p>";
                        cardList.style.display = "none";
                        return;
                    }

                    let html = '<div class="card-container">';
                    games.forEach(function (g) {
                        const id       = g.game_id || "";
                        const title    = escapeHtml(g.title || "Untitled");
                        const platform = escapeHtml(g.platform || "Unknown");
                        const price    = (g.price !== undefined && g.price !== null)
                            ? Number(g.price).toFixed(2)
                            : "0.00";
                        const stock    = (g.stock !== undefined && g.stock !== null)
                            ? parseInt(g.stock, 10)
                            : 0;

                        html += ''
                            + '<div class="game-card">'
                            +   '<h3>' + title + '</h3>'
                            +   '<p><strong>Platform:</strong> ' + platform + '</p>'
                            +   '<p><strong>Price:</strong> $' + price + '</p>'
                            +   '<p><strong>Stock:</strong> ' + stock + ' available</p>'
                            +   '<a href="' + baseUrl + '/index.php?url=game/detail/' + id + '" class="details-btn">View Details</a>'
                            + '</div>';
                    });
                    html += '</div>';

                    resultsDiv.innerHTML = html;
                    cardList.style.display = "none";
                }

                function doSearch(event) {
                    if (event) {
                        event.preventDefault();
                    }
                    const q = input.value.trim();
                    if (q === "") {
                        clearResults();
                        return;
                    }

                    const url = baseUrl + "/index.php?url=game/search/" + encodeURIComponent(q);

                    fetch(url, {headers: {"Accept": "application/json"}})
                        .then(function (response) { return response.json(); })
                        .then(function (data) { renderCards(data); })
                        .catch(function () {
                            resultsDiv.innerHTML = "<p class=\"error-message\">There was a problem searching. Please try again.</p>";
                            cardList.style.display = "none";
                        });
                }

                if (button) {
                    button.addEventListener("click", doSearch);
                }
                if (input) {
                    input.addEventListener("keyup", function (e) {
                        if (e.key === "Enter") {
                            doSearch(e);
                        }
                    });
                }
            })();
        </script>

        <!-- CSS -->
        <style>
            .inventory-header {
                margin-bottom: 10px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .add-btn {
                display: inline-block;
                padding: 8px 14px;
                background: #4CAF50;
                color: #fff;
                text-decoration: none;
                border-radius: 6px;
                font-size: 14px;
            }

            .add-btn:hover {
                background: #45a049;
            }

            /* keep your existing styles */
        </style>

        <?php
        $this->footer();
    }

    private function inferGenre($title)
    {
        $genres = [
            'Eclipse Vanguard'   => 'Action RPG',
            'Mythborne Odyssey'  => 'Multiplayer Online',
            'Street League 24'   => 'Sports / Skateboarding',
            'Apex Velocity'      => 'Combat Racing',
            'Mindshift'          => 'Psychological Thriller',
            'Crimson Rift'       => 'Fantasy RPG',
            "Tactician's Oath"   => 'Tactical RPG'
        ];
        return $genres[$title] ?? 'Genre Pending';
    }
}
