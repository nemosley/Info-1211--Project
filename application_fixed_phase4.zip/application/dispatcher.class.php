<?php
/**
 *Author:Nevaeh Mosley
 *Date:12/5/2025
 *File:dispatcher.class.php
 *Description
 */

/**
 * Dispatcher class
 * Handles parsing REST-style URLs and routing to the correct controller/method.
 * Author: Nevaeh Mosley
 * Date: 12/05/2025
 */
class Dispatcher
{
    public function dispatch()
    {
        // Parse REST-style URL: controller/method/param
        // Example: index.php?url=game/detail/3
        $url = isset($_GET['url']) ? trim($_GET['url'], '/') : '';
        $parts = $url === '' ? [] : explode('/', $url);

        // Defaults
        $controller_name = $parts[0] ?? 'game';
        $method = $parts[1] ?? 'index';
        $param = $parts[2] ?? null;

        // Build controller class name (game → GameController)
        $controller_class = ucfirst($controller_name) . 'Controller';

        // Fallback if class doesn’t exist
        if (!class_exists($controller_class)) {
            $controller_class = 'GameController';
            $method = 'index';
        }

        // Instantiate controller (autoload will load the file)
        $controller = new $controller_class();

        // Fallback if method doesn’t exist
        if (!method_exists($controller, $method)) {
            $method = 'index';
        }

        // Execute request
        if ($param !== null) {
            $controller->$method($param);
        } else {
            $controller->$method();
        }
    }
}
