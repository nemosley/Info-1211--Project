<?php
/**
 * Author: Nevaeh Mosley
 * File: game_create.class.php
 * Description: View that shows a form for adding a new game.
 */

class GameCreateForm extends View
{
    /**
     * @param array $errors  Optional list of validation / save error messages.
     * @param array $old     Previously submitted values so the form can be repopulated.
     */
    public function display(array $errors = [], array $old = [])
    {
        $this->header("Add New Game");
        ?>
        <h1>Add New Game</h1>

        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <ul>
                    <?php foreach ($errors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="<?= BASE_URL ?>/index.php?url=game/create" class="game-form">
            <div class="form-row">
                <label for="title">Title:</label>
                <input
                    type="text"
                    id="title"
                    name="title"
                    required
                    value="<?= htmlspecialchars($old['title'] ?? '') ?>"
                >
            </div>

            <div class="form-row">
                <label for="platform">Platform:</label>
                <select id="platform" name="platform">
                    <?php
                    $platforms = ['PS5', 'Xbox', 'PC', 'Switch'];
                    $currentPlatform = $old['platform'] ?? '';
                    foreach ($platforms as $p):
                    ?>
                        <option value="<?= $p ?>" <?= ($p === $currentPlatform) ? 'selected' : '' ?>>
                            <?= $p ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-row">
                <label for="category_id">Category ID:</label>
                <input
                    type="number"
                    id="category_id"
                    name="category_id"
                    min="1"
                    value="<?= htmlspecialchars($old['category_id'] ?? '1') ?>"
                >
                <span class="hint">Use the numeric ID from the categories table.</span>
            </div>

            <div class="form-row">
                <label for="price">Price ($):</label>
                <input
                    type="number"
                    id="price"
                    name="price"
                    step="0.01"
                    min="0"
                    value="<?= htmlspecialchars($old['price'] ?? '0.00') ?>"
                >
            </div>

            <div class="form-row">
                <label for="stock">Stock:</label>
                <input
                    type="number"
                    id="stock"
                    name="stock"
                    min="0"
                    value="<?= htmlspecialchars($old['stock'] ?? '0') ?>"
                >
            </div>

            <div class="form-row">
                <label for="available">Available:</label>
                <select id="available" name="available">
                    <?php
                    $available = isset($old['available']) ? (int)$old['available'] : 1;
                    ?>
                    <option value="1" <?= $available === 1 ? 'selected' : '' ?>>Yes</option>
                    <option value="0" <?= $available === 0 ? 'selected' : '' ?>>No</option>
                </select>
            </div>

            <div class="form-row">
                <label for="description">Description:</label>
                <textarea
                    id="description"
                    name="description"
                    rows="5"
                ><?= htmlspecialchars($old['description'] ?? '') ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit">Add Game</button>
                <a href="<?= BASE_URL ?>/index.php?url=game/index" class="cancel-link">Cancel</a>
            </div>
        </form>

        <style>
            .game-form {
                max-width: 640px;
                margin: 20px auto;
                padding: 20px;
                border: 1px solid #ccc;
                border-radius: 8px;
                background-color: #fafafa;
            }
            .form-row {
                margin-bottom: 12px;
                display: flex;
                flex-direction: column;
            }
            .form-row label {
                font-weight: bold;
                margin-bottom: 4px;
            }
            .form-row input,
            .form-row select,
            .form-row textarea {
                padding: 6px 8px;
                border-radius: 4px;
                border: 1px solid #ccc;
                font-size: 14px;
            }
            .form-actions {
                margin-top: 16px;
            }
            .form-actions button {
                padding: 8px 16px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }
            .cancel-link {
                margin-left: 10px;
            }
            .error-box {
                border: 1px solid #c0392b;
                background: #fdecea;
                color: #c0392b;
                padding: 10px;
                margin-bottom: 15px;
                border-radius: 4px;
            }
            .error-box ul {
                margin: 0;
                padding-left: 18px;
            }
            .hint {
                font-size: 12px;
                color: #666;
                margin-top: 2px;
            }
        </style>
        <?php
        $this->footer();
    }
}
