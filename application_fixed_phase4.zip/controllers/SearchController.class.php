<?php
class SearchController extends Controller
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getDatabase();
    }

    public function index()
    {
        header('Content-Type: application/json');

        $q = trim($_GET['q'] ?? '');
        $mode = strtoupper(trim($_GET['mode'] ?? 'OR')); // OR or AND

        if ($q === '') {
            echo json_encode([]);
            return;
        }

        // Split into keywords
        $keywords = array_filter(preg_split('/\s+/', $q));
        if (empty($keywords)) {
            echo json_encode([]);
            return;
        }

        // Build WHERE across one field (title)
        $clauses = [];
        $params  = [];
        $types   = '';

        foreach ($keywords as $kw) {
            $clauses[] = 'title LIKE ?';
            $params[]  = '%' . $kw . '%';
            $types    .= 's';
        }

        $glue = ($mode === 'AND') ? ' AND ' : ' OR ';
        $sql = "SELECT game_id, title, platform, price, stock, description, added_on
                FROM games
                WHERE " . implode($glue, $clauses) . "
                ORDER BY title ASC";

        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            echo json_encode(['error' => 'SQL prepare failed: ' . $this->db->error]);
            return;
        }

        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        if (!$stmt->execute()) {
            echo json_encode(['error' => 'SQL execute failed: ' . $stmt->error]);
            $stmt->close();
            return;
        }

        $result = $stmt->get_result();
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));

        $stmt->close();
    }
}
