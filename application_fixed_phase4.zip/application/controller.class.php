<?php
/**
 * Base controller class.
 * Can be extended for common controller behavior.
 */

class Controller
{
    // For now this is minimal; extend later if needed.
}
