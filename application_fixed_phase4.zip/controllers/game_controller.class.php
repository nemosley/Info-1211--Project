<?php
/**
 * Author: Benjamin Egger-Torke
 * File: game_controller.class.php
 * Description: Controller class to handle game requests.
 */
class GameController extends Controller
{
    private $gameModel;

    public function __construct()
    {
        $this->gameModel = new GameModel();
    }

    /**
     * Route: /game/index
     * List all products (games inventory page).
     */
    public function index()
    {
        $games = $this->gameModel->getAllGames();
        $view = new GameIndex();
        $view->display($games);
    }

    /**
     * Route: /game/detail/{id}
     * Display details of a specific product (game).
     */
    public function detail($id)
    {
        $id = (int)$id;
        $game = $this->gameModel->getGameById($id);

        if (!$game) {
            $view = new ErrorView();
            $view->display("Game not found.");
            return;
        }

        $view = new GameDetail();
        $view->display($game);
    }

    /**
     * Route: /game/search/{terms}
     * Handle search requests (OR logic on the title field).
     */
    public function search($query)
    {
        // Decode the URL segment so multi-word searches work (e.g. "apex velocity").
        $query = urldecode($query);

        $results = $this->gameModel->searchGamesOr($query);

        header('Content-Type: application/json');
        echo json_encode($results);
    }

    /**
     * Route: /game/create
     * Display the add-game form on GET and insert a new record on POST.
     */
    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'title'       => trim($_POST['title'] ?? ''),
                'platform'    => trim($_POST['platform'] ?? ''),
                'category_id' => (int)($_POST['category_id'] ?? 0),
                'description' => trim($_POST['description'] ?? ''),
                'price'       => (float)($_POST['price'] ?? 0),
                'stock'       => (int)($_POST['stock'] ?? 0),
                'available'   => isset($_POST['available']) ? (int)$_POST['available'] : 1,
            ];

            $ok = $this->gameModel->create($data);

            if ($ok) {
                // On success, go back to the inventory page.
                header("Location: " . BASE_URL . "/index.php?url=game/index");
                exit;
            }

            // If something went wrong, redisplay the form with a simple error message.
            $view = new GameCreateForm();
            $view->display(['Unable to save game. Please try again.'], $data);
        } else {
            // Initial load of the empty form
            $view = new GameCreateForm();
            $view->display();
        }
    }

    /**
     * Route: /game/update/{id}
     * Update an existing game.
     */
    public function update($id)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ok = $this->gameModel->update((int)$id, $_POST);
            header('Content-Type: application/json');
            echo json_encode(['ok' => $ok]);
        }
    }

    /**
     * Route: /game/delete/{id}
     * Delete a game.
     */
    public function delete($id)
    {
        $ok = $this->gameModel->delete((int)$id);
        header('Content-Type: application/json');
        echo json_encode(['ok' => $ok]);
    }
}
