/*
 * This script contains AJAX methods for game title suggestions
 */
var xmlHttp;
var numGames = 0;   // total number of suggested game titles
var activeGame = -1; // currently selected suggestion
var searchBoxObj, suggestionBoxObj, activeGameObj;

// create an XMLHttpRequest object compatible with most browsers
function createXmlHttpRequestObject() {
    if (window.ActiveXObject) {
        return new ActiveXObject("Microsoft.XMLHTTP");
    } else if (window.XMLHttpRequest) {
        return new XMLHttpRequest();
    } else {
        alert("Error creating the XMLHttpRequest object.");
        return false;
    }
}

// initial actions when the page loads
window.onload = function () {
    xmlHttp = createXmlHttpRequestObject();
    searchBoxObj = document.getElementById('gameSearchBox');
    suggestionBoxObj = document.getElementById('gameSuggestionBox');
};

// hide suggestions when clicking elsewhere
window.onclick = function () {
    suggestionBoxObj.style.display = 'none';
};

// send AJAX request to server
function suggestGames(query) {
    if (query === "") {
        suggestionBoxObj.innerHTML = "";
        suggestionBoxObj.style.display = 'none';
        return;
    }

    xmlHttp.open("GET", base_url + "/search/index?q=" + encodeURIComponent(query), true);

    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
            var games = JSON.parse(xmlHttp.responseText);
            displayGameTitles(games);
        }
    };

    xmlHttp.send(null);
}

// populate suggestion box with spans containing all titles
function displayGameTitles(games) {
    numGames = games.length;
    activeGame = -1;

    if (numGames === 0) {
        suggestionBoxObj.style.display = 'none';
        return;
    }

    var divContent = "";
    for (var i = 0; i < games.length; i++) {
        divContent += "<span id='g_" + i + "' onclick='clickGame(this)'>" + games[i].title + "</span>";
    }

    suggestionBoxObj.innerHTML = divContent;
    suggestionBoxObj.style.display = 'block';
}

// handle keyup events
function handleGameKeyUp(e) {
    e = (!e) ? window.event : e;

    if (e.keyCode !== 38 && e.keyCode !== 40) {
        suggestGames(e.target.value);
        return;
    }

    // up arrow
    if (e.keyCode === 38 && activeGame > 0) {
        activeGameObj.style.backgroundColor = "#FFF";
        activeGame--;
        activeGameObj = document.getElementById("g_" + activeGame);
        activeGameObj.style.backgroundColor = "#F5DEB3";
        searchBoxObj.value = activeGameObj.innerHTML;
        return;
    }

    // down arrow
    if (e.keyCode === 40 && activeGame < numGames - 1) {
        if (typeof(activeGameObj) != "undefined") {
            activeGameObj.style.backgroundColor = "#FFF";
        }
        activeGame++;
        activeGameObj = document.getElementById("g_" + activeGame);
        activeGameObj.style.backgroundColor = "#F5DEB3";
        searchBoxObj.value = activeGameObj.innerHTML;
    }
}

// when a title is clicked
function clickGame(gameSpan) {
    searchBoxObj.value = gameSpan.innerHTML;
    suggestionBoxObj.style.display = 'none';
}
