<?php

/*
 * Author: Nevaeh Mosley
 * Date: 12/05/2025
 * File: config.php
 * Description: set application settings for Draft2 FinalProject
 */

// ---- ERROR REPORTING ----
error_reporting(E_ALL);

// ---- LOCAL TIME ZONE ----
date_default_timezone_set('America/New_York');

// ---- BASE URL ----
define("BASE_URL", "/I211/Draft2");

/*************************************************************************************
 *                       settings for games                                          *
 ************************************************************************************/

// ---- DATABASE SETTINGS ----
define("DB_HOST", "localhost");
define("DB_USER", "root");        // default XAMPP user
define("DB_PASSWORD", "");        // default XAMPP password
define("DB_NAME", "games_db");    // ✅ corrected schema name

// ---- MEDIA PATHS ----
define("GAME_IMG", "www/img/games/");

// ---- AUTOLOADER ----
spl_autoload_register(function ($class_name) {
    $map = [
        'Database'        => 'application/database.class.php',
        'Controller'      => 'application/controller.class.php',
        'View'            => 'application/view.class.php',
        // Models
        'GameModel'       => 'models/game_model.class.php',
        // Controllers
        'GameController'  => 'controllers/game_controller.class.php',
        'SearchController'=> 'controllers/SearchController.class.php',
        // Views
        'GameIndex'       => 'views/game/game_index.class.php',
        'GameDetail'      => 'views/game/game_detail.class.php',
        'GameSearch'      => 'views/game/game_search.class.php',
        'GameCreateForm'  => 'views/game/game_create.class.php',
    ];

    if (isset($map[$class_name]) && file_exists($map[$class_name])) {
        require_once $map[$class_name];
    }
});

