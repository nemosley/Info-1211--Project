<?php
/**
 *Author:Nevaeh Mosley
 *Date:12/6/2025
 *File:game_search.class.php
 *Description
 */

class GameSearch extends View
{
    public function display(string $terms, $games)
    {
        $this->header("Search Results");
        ?>
        <div id="main-header">
            Search Results for <i><?= htmlspecialchars($terms) ?></i>
        </div>
        <span class="rcd-numbers">
            <?php
            echo (!is_array($games) || empty($games))
                ? "( 0 - 0 )"
                : "( 1 - " . count($games) . " )";
            ?>
        </span>
        <hr>

        <div class="card-container">
            <?php $this->renderGames($games); ?>
        </div>

        <a href="<?= BASE_URL ?>/game/index">Go to game list</a>
        <?php
        $this->footer();
    }

    public function partial($games)
    {
        echo '<div class="card-container">';
        $this->renderGames($games);
        echo '</div>';
    }

    private function renderGames($games)
    {
        if (!is_array($games) || empty($games)) {
            echo "No game was found.<br><br><br><br><br>";
            return;
        }

        foreach ($games as $game) {
            $id       = (int)($game['game_id'] ?? 0);
            $title    = htmlspecialchars($game['title'] ?? 'Untitled');
            $platform = htmlspecialchars($game['platform'] ?? 'Unknown');
            $category = htmlspecialchars($game['category_name'] ?? '');
            $price    = isset($game['price'])
                ? number_format((float)$game['price'], 2)
                : '0.00';

            echo "<div class='game-card'><p>
                    <a href='" . BASE_URL . "/game/detail/$id'>
                        <span class='game-title'>$title</span>
                    </a>
                    <span><br>Platform: $platform<br>Category: $category<br>Price: $$price</span>
                </p></div>";
        }
    }
}
