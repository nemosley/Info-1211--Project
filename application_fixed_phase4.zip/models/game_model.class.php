<?php
/**
 * Author: Nevaeh Mosley
 * File: game_model.class.php
 * Description: Model class for games. Retrieves all games and a specific game, plus create.
 */

class GameModel
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getDatabase();
    }

    /**
     * Fetch all games from the database.
     * @return array
     */
    public function getAllGames()
    {
        $sql = "SELECT * FROM games ORDER BY title ASC";
        $result = $this->db->query($sql);

        $games = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $games[] = $row;
            }
        }
        return $games;
    }

    /**
     * Fetch a single game by ID.
     * @param int $id
     * @return array|null
     */
    public function getGameById($id)
    {
        $sql = "SELECT * FROM games WHERE game_id = ?";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) return null;

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $result = $stmt->get_result();
        $game = $result->fetch_assoc() ?: null;

        $stmt->close();
        return $game;
    }


    /**
     * Search games by title using multi-word OR logic.
     * Each word is matched against the title field.
     *
     * @param string $query
     * @return array
     */
    public function searchGamesOr(string $query): array
    {
        $query = trim($query);
        if ($query === '') {
            return [];
        }

        // Split on whitespace into individual keywords
        $keywords = array_filter(preg_split('/\s+/', $query));
        if (empty($keywords)) {
            return [];
        }

        $clauses = [];
        $params  = [];
        $types   = '';

        foreach ($keywords as $kw) {
            $clauses[] = 'title LIKE ?';
            $params[]  = '%' . $kw . '%';
            $types    .= 's';
        }

        $sql = "SELECT * FROM games WHERE " . implode(' OR ', $clauses) . " ORDER BY title ASC";

        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            return [];
        }

        $stmt->bind_param($types, ...$params);
        $stmt->execute();

        $result = $stmt->get_result();
        $games = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

        $stmt->close();
        return $games;
    }

    /**
     * Create a new game record.
     * @param array $data
     * @return bool
     */
    public function create(array $data): bool
    {
        $sql = "INSERT INTO games (title, platform, category_id, description, price, stock, available)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) return false;

        $stmt->bind_param(
            "ssisdii",
            $data['title'],
            $data['platform'],
            $data['category_id'],
            $data['description'],
            $data['price'],
            $data['stock'],
            $data['available']
        );

        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }
}
