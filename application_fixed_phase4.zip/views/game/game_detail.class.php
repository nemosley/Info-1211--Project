<?php
/**
 * Author: Nevaeh Mosley
 * File: game_detail.class.php
 * Description: View to present details of a single game.
 */

class GameDetail extends View
{
    public function display($game)
    {
        $this->header("Game Details");

        // Defensive fallback values
        $title       = htmlspecialchars($game['title'] ?? 'Untitled');
        $platform    = htmlspecialchars($game['platform'] ?? 'Unknown');
        $category    = htmlspecialchars($game['category_name'] ?? $this->inferGenre($title));
        $price       = isset($game['price']) ? number_format((float)$game['price'], 2) : '0.00';
        $stock       = isset($game['stock']) ? (int)$game['stock'] : 0;
        $available   = !empty($game['available']) ? 'Yes' : 'No';
        $added_on    = htmlspecialchars($game['added_on'] ?? 'Unknown');
        $description = htmlspecialchars($game['description'] ?? 'No description available.');
        ?>

        <div class="top-row"><h2><?= $title ?></h2></div>

        <div class="middle-row">
            <ul>
                <li><strong>Platform:</strong> <?= $platform ?></li>
                <li><strong>Category:</strong> <?= $category ?></li>
                <li><strong>Price:</strong> $<?= $price ?></li>
                <li><strong>Stock:</strong> <?= $stock ?></li>
                <li><strong>Available:</strong> <?= $available ?></li>
                <li><strong>Added On:</strong> <?= $added_on ?></li>
            </ul>

            <h3>Description:</h3>
            <p><?= $description ?></p>

            <a href="<?= BASE_URL ?>/index.php?url=game/index">Back to Inventory</a>
        </div>

        <div class="bottom-row"></div>
        <?php
        $this->footer();
    }

    /**
     * Infer genre  category_name
     * Expanded names
     */
    private function inferGenre($title)
    {
        $genres = [
            'Eclipse Vanguard'    => 'Action Role-Playing Game',
            'Mythborne Odyssey'   => 'Massively Multiplayer Online Role-Playing Game',
            'Street League 24'    => 'Sports / Skateboarding',
            'Apex Velocity'       => 'Combat Racing',
            'Mindshift'           => 'Psychological Thriller',
            'Crimson Rift'        => 'Fantasy Role-Playing Game',
            'Tactician\'s Oath'   => 'Tactical Role-Playing Game'
        ];
        return $genres[$title] ?? 'Genre Pending';
    }
}
